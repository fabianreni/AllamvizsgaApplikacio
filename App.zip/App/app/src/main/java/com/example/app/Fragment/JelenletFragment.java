package com.example.app.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.app.Adapter.JelenletAdapter;
import com.example.app.Class.Jelenlet;
import com.example.app.MainActivity;
import com.example.app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class JelenletFragment extends Fragment {
    ArrayList<Jelenlet> jelen;
    ArrayList<Jelenlet> jelenaktualis;
    FirebaseUser user;
    Button btnLogOFF, visszakurzus;
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    DatabaseReference databaseReference;
    Spinner spinnerProperty;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context = getActivity();
        ((MainActivity) context).setTitle("Jelenlétek");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_jelenlet, container, false);
        user= FirebaseAuth.getInstance().getCurrentUser();
        final String username = user.getDisplayName();
        SharedPreferences statusz = PreferenceManager.getDefaultSharedPreferences( getActivity());
        final String value = statusz.getString("Statusz", "");
        final String kurzus=statusz.getString("Kurzus","");
        TextView cim=view.findViewById(R.id.tv_cim);
        if(value.equals("Tanár")){
            cim.setText("Diákok jelenlétei"+" "+kurzus+"ból");
        }else{
            cim.setText(username.toUpperCase()+" "+"jelenlétei"+" "+kurzus+"ból");
        }


        recyclerView=view.findViewById(R.id.jelenletek);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        jelen=new ArrayList<>();
        jelenaktualis=new ArrayList<>();

        databaseReference= FirebaseDatabase.getInstance().getReference().child("Datum").child(kurzus);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                        for(DataSnapshot snapshot1:snapshot.getChildren()) {

                            jelen.add(snapshot1.getValue(Jelenlet.class));
                            if(snapshot1.getValue(Jelenlet.class).getName().toLowerCase().equals(username.toLowerCase())) {
                                jelenaktualis .add(snapshot1.getValue(Jelenlet.class));
                            }
                        }
                    }
                    if(value.equals("Tanár")){
                        adapter = new JelenletAdapter(getActivity(), jelen);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    }
                    else{
                        adapter = new JelenletAdapter(getActivity(), jelenaktualis);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    }

                }
            }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {
    }
});

        btnLogOFF= view.findViewById(R.id.bt_logoff);
        btnLogOFF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.mainactivity, new LoginFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        visszakurzus=view.findViewById(R.id.bt_kurzusValaszt);
        visszakurzus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.mainactivity, new FirstPageFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });



        return view;
    }
}


