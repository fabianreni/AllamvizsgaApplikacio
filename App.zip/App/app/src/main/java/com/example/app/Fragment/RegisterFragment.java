package com.example.app.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.app.Class.Felhasznalo;
import com.example.app.MainActivity;
import com.example.app.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;


public class RegisterFragment extends Fragment {
    public EditText emailId,name, passwd;
    Button btnSignUp;
    TextView signIn;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;
    Spinner spinner;
    DatabaseReference mDatabase;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context = getActivity();
        ((MainActivity) context).setTitle("Regisztráció");
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_register, container, false);

        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        name= view.findViewById(R.id.et_name);
        emailId = view.findViewById(R.id.et_email);
        passwd = view.findViewById(R.id.et_password);
        btnSignUp = view.findViewById(R.id.btnSignUp);
        signIn =view.findViewById(R.id.TVSignIn);
        spinner=view.findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(getActivity(), R.array.tipus,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                SharedPreferences statusz = PreferenceManager.getDefaultSharedPreferences( getActivity());
                SharedPreferences.Editor statuszEditor = statusz.edit();
                statuszEditor.putString("Statusz",spinner.getSelectedItem().toString());
                statuszEditor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String emailID = emailId.getText().toString();
                final String paswd = passwd.getText().toString();
                final String names=name.getText().toString();
                final String spinv=spinner.getSelectedItem().toString();
                Felhasznalo u=new Felhasznalo(names,emailID);
                final Map<String,Object> u1= new HashMap<>();
                u1.put(names,u);
                Map<String,  String> user1=new HashMap<>();
                user1.put("Name",names);
                user1.put("Email",emailID);
                user1.put("Status",spinv);
                mDatabase.child("Users").child(names).setValue(user1);
                if (emailID.isEmpty()) {
                    emailId.setError("Írja be az e-mail címet!");
                    emailId.requestFocus();
                } else if (paswd.isEmpty()) {
                    passwd.setError("Hozzon létre jelszót");
                    passwd.requestFocus();
                } else if(names.isEmpty()){
                    name.setError("Írja be a nevét!");
                    name.requestFocus();
                } else if (emailID.isEmpty() && paswd.isEmpty() &&  names.isEmpty()) {
                    Toast.makeText(getActivity(), "Üres mező!!", Toast.LENGTH_SHORT).show();
                } else if (!(emailID.isEmpty() && paswd.isEmpty() && names.isEmpty())) {
                    firebaseAuth.createUserWithEmailAndPassword(emailID, paswd).addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task task) {

                            if (!task.isSuccessful()) {
                                Toast.makeText(getContext(),
                                        "Sikertelen regisztráció: " + task.getException().getMessage(),
                                        Toast.LENGTH_SHORT).show();


                            } else {
                                Toast.makeText(getContext(),
                                        "Sikeres regisztráció, most jelentkezzen be!",
                                        Toast.LENGTH_SHORT).show();
                                //databaseReference.child("User").child("Diak").child(names).setValue(u1);

                                //username elmentese
                                UserProfileChangeRequest profileChangeRequest = new UserProfileChangeRequest.Builder().setDisplayName(names).build();
//
//                                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
//                                fragmentTransaction.replace(R.id.mainactivity, new FirstPageFragment());
//                                fragmentTransaction.addToBackStack(null);
//                                fragmentTransaction.commit();


                                user = firebaseAuth.getCurrentUser();

                                //jelzed, hogy sikerult, vagy nem
                                user.updateProfile(profileChangeRequest).addOnCompleteListener(new OnCompleteListener<Void>()
                                {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task)
                                    {
                                        if(task.isSuccessful())
                                        {
                                            Log.d(TAG,"Név beállítva");
                                        }
                                        else
                                        {
                                            Log.d(TAG,"Nincs név beállítva");
                                        }
                                    }
                                });
                                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                                fragmentTransaction.replace(R.id.mainactivity, new LoginFragment());
                                fragmentTransaction.addToBackStack(null);
                                fragmentTransaction.commit();
                            }
                        }
                    });
                } else {
                    Toast.makeText(getActivity(), "Hiba", Toast.LENGTH_SHORT).show();
                }
            }
        });
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.mainactivity, new LoginFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return view;
    }

}
