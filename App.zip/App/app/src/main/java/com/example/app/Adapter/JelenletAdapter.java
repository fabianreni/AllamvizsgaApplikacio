package com.example.app.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.Class.Jelenlet;
import com.example.app.R;

import java.util.ArrayList;
import java.util.List;

public class JelenletAdapter extends RecyclerView.Adapter<JelenletAdapter.JelenletViewHolder> implements Filterable {
    Context context;
    ArrayList<Jelenlet> jelenlet;
    ArrayList<Jelenlet> jelenletteljes;
    public JelenletAdapter(Context context, ArrayList<Jelenlet> j)
    {
        this.context = context;
        this.jelenlet = j;
        jelenletteljes=new ArrayList<>(j);
    }

    @Override
    public Filter getFilter() {
        return peldaFilter;
    }
    private  Filter peldaFilter=new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Jelenlet> filterLista=new ArrayList<>();
            if(constraint==null || constraint.length()==0){
                filterLista.addAll(jelenletteljes);
            }
            else {
                String filterP=constraint.toString().toLowerCase().trim();
                for(Jelenlet item: jelenletteljes){
                    if(item.getName().toLowerCase().contains(filterP)){
                        filterLista.add(item);
                    }
                }
            }
            FilterResults results=new FilterResults();
            results.values=filterLista;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            jelenlet.clear();
            jelenlet.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };

    public static class JelenletViewHolder extends RecyclerView.ViewHolder
    {
        private TextView datum;
        private  TextView nev;

        public JelenletViewHolder(View v)
        {
            super(v);

            datum=itemView.findViewById(R.id.tv_date);
            nev=itemView.findViewById(R.id.tv_name);

        }

    }


    @NonNull
    @Override
    public JelenletViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.first_page_elements,parent,false);

        return new JelenletViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull JelenletViewHolder holder, int position) {
        holder.nev.setText(jelenlet.get(position).getName()+":");
        holder.datum.setText( jelenlet.get(position).getDate());
    }

    @Override
    public int getItemCount() {
        return jelenlet.size();
    }

}
