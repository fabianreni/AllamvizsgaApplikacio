package com.example.app.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.app.Adapter.JelenletAdapter;
import com.example.app.Class.Felhasznalo;
import com.example.app.Class.Jelenlet;
import com.example.app.MainActivity;
import com.example.app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.EventListener;
import java.util.List;


public class FirstPageFragment extends Fragment {
    Button bt_jelenlet;
    Spinner kurzus;
    FirebaseUser user;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context = getActivity();
        ((MainActivity) context).setTitle("Kurzus választás");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_first_page, container, false);
        bt_jelenlet=view.findViewById(R.id.bt_jelenlet);
        kurzus=view.findViewById(R.id.spiner_kurzus);
        user= FirebaseAuth.getInstance().getCurrentUser();
        final String username = user.getDisplayName();
        SharedPreferences statusz = PreferenceManager.getDefaultSharedPreferences( getActivity());
        final String tanar_diak = statusz.getString("Statusz", "");
//        Toast.makeText(getContext(), username, Toast.LENGTH_SHORT).show();
        DatabaseReference dr= FirebaseDatabase.getInstance().getReference().child("Users").child(username);
        dr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String s = dataSnapshot.child("Status").getValue().toString();
                if ((tanar_diak.equals(s))) {
                    Toast.makeText(getContext(), "Ön megfelelő státuszal lépet be, "+tanar_diak, Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getContext(), "Ön nem megfelelő státuszal lépet be, Nem "+tanar_diak+ ". Lépjen be "+s+"ként", Toast.LENGTH_SHORT).show();
                    FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.mainactivity, new LoginFragment());
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        if(tanar_diak.equals("Tanár")){
            DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference().child("Kurzusok");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                {final List<String> propertyAddressList = new ArrayList<String>();
                    if(dataSnapshot.exists()) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            String propertyAddress = snapshot.getKey();
                            for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                String nev = snapshot1.getKey();
                                if (nev.equals(username)) {
                                    if (propertyAddress != null) {
                                        propertyAddressList.add(propertyAddress.toString());
                                    }

                                }
                            }
                        }
                        ArrayAdapter<String> addressAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, propertyAddressList);
                        addressAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        kurzus.setAdapter(addressAdapter);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }else{
            DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference().child("Kurzusok");
            databaseReference.addValueEventListener(new ValueEventListener() {
           @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final List<String> propertyAddressList = new ArrayList<String>();

                for (DataSnapshot addressSnapshot: dataSnapshot.getChildren()) {
                    String propertyAddress = addressSnapshot.getKey();
                    if (propertyAddress!=null){
                        propertyAddressList.add(propertyAddress.toString());
                    }
                }
                ArrayAdapter<String> addressAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, propertyAddressList);
                addressAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                kurzus.setAdapter(addressAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        }

        kurzus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                SharedPreferences statusz = PreferenceManager.getDefaultSharedPreferences( getActivity());
                SharedPreferences.Editor statuszEditor = statusz.edit();
                statuszEditor.putString("Kurzus",kurzus.getSelectedItem().toString());
                statuszEditor.commit();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        bt_jelenlet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.mainactivity, new JelenletFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        return view;
    }
}
