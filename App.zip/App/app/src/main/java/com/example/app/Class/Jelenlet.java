package com.example.app.Class;

public class Jelenlet {
    String date;
    String name;
    public Jelenlet(){

    }
    public Jelenlet(String date,String name  ) {
        this.date = date;
        this.name=name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
